﻿using Lib.Repository.Entities;

namespace Lib.Repository.Services;

public static class BattleService
{

}
